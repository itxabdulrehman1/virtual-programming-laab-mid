﻿using System;
using System.Collections.Generic;

abstract class User
{
    public string UserID { get; set; }
    public string Name { get; set; }
    public string PhoneNumber { get; set; }

    public abstract void Register();
    public abstract void Login();
    public void DisplayProfile()
    {
        Console.WriteLine($"User  ID: {UserID}, Name: {Name}, Phone: {PhoneNumber}");
    }
}

class Rider : User
{
    public List<Trip> RideHistory { get; set; } = new List<Trip>();

    public override void Register()
    {
        Console.Write("Enter your name: ");
        Name = Console.ReadLine();
        Console.Write("Enter your phone number: ");
        PhoneNumber = Console.ReadLine();
        UserID = Guid.NewGuid().ToString();
        Console.WriteLine("Rider registered successfully.");
    }

    public override void Login()
    {
        Console.WriteLine("Rider logged in.");
    }

    public void RequestRide(RideSharingSystem system)
    {
        Console.Write("Enter start location: ");
        string startLocation = Console.ReadLine();
        Console.Write("Enter destination: ");
        string destination = Console.ReadLine();
        system.RequestRide(this, startLocation, destination);
    }

    public void ViewRideHistory()
    {
        Console.WriteLine("Ride History:");
        foreach (var trip in RideHistory)
        {
            trip.DisplayTripDetails();
        }
    }
}

class Driver : User
{
    public string DriverID { get; set; }
    public string VehicleDetails { get; set; }
    public bool IsAvailable { get; set; } = true;
    public List<Trip> TripHistory { get; set; } = new List<Trip>();

    public override void Register()
    {
        Console.Write("Enter your name: ");
        Name = Console.ReadLine();
        Console.Write("Enter your phone number: ");
        PhoneNumber = Console.ReadLine();
        Console.Write("Enter vehicle details: ");
        VehicleDetails = Console.ReadLine();
        UserID = Guid.NewGuid().ToString();
        DriverID = Guid.NewGuid().ToString();
        Console.WriteLine("Driver registered successfully.");
    }

    public override void Login()
    {
        Console.WriteLine("Driver logged in.");
    }

    public void AcceptRide(Trip trip)
    {
        if (IsAvailable)
        {
            IsAvailable = false;
            trip.DriverName = Name;
            trip.Status = "In Progress";
            TripHistory.Add(trip);
            Console.WriteLine($"{Name} accepted the ride.");
        }
        else
        {
            Console.WriteLine("Driver is not available.");
        }
    }

    public void ToggleAvailability()
    {
        IsAvailable = !IsAvailable;
        Console.WriteLine(IsAvailable ? "Driver is now available." : "Driver is now unavailable.");
    }

    public void ViewTripHistory()
    {
        Console.WriteLine("Trip History:");
        foreach (var trip in TripHistory)
        {
            trip.DisplayTripDetails();
        }
    }
}

class Trip
{
    public string TripID { get; set; }
    public string RiderName { get; set; }
    public string DriverName { get; set; }
    public string StartLocation { get; set; }
    public string Destination { get; set; }
    public decimal Fare { get; set; }
    public string Status { get; set; }

    public Trip(string riderName, string startLocation, string destination)
    {
        TripID = Guid.NewGuid().ToString();
        RiderName = riderName;
        StartLocation = startLocation;
        Destination = destination;
        Status = "Requested";
        Fare = CalculateFare();
    }

    public decimal CalculateFare()
    {
        // Simple fare calculation based on distance (for demonstration)
        return new Random().Next(10, 50);
    }

    public void StartTrip()
    {
        Status = "In Progress";
        Console.WriteLine("Trip started.");
    }

    public void EndTrip()
    {
        Status = "Completed";
        Console.WriteLine("Trip ended.");
    }

    public void DisplayTripDetails()
    {
        Console.WriteLine($"Trip ID: {TripID}, Rider: {RiderName}, Driver: {DriverName}, Start: {StartLocation}, Destination: {Destination}, Fare: {Fare:C}, Status: {Status}");
    }
}

class RideSharingSystem
{
    public List<Rider> RegisteredRiders { get; set; } = new List<Rider>();
    public List<Driver> RegisteredDrivers { get; set; } = new List<Driver>();
    public List<Trip> AvailableTrips { get; set; } = new List<Trip>();

    public void RegisterUser(User user)
    {
        if (user is Rider)
        {
            RegisteredRiders.Add((Rider)user);
        }
        else if (user is Driver)
        {
            RegisteredDrivers.Add((Driver)user);
        }
    }

    public void RequestRide(Rider rider, string startLocation, string destination)
    {
        Trip trip = new Trip(rider.Name, startLocation, destination);
        AvailableTrips.Add(trip);
        Console.WriteLine("Ride requested successfully.");
    }

    public void FindAvailableDriver()
    {
        foreach (var driver in RegisteredDrivers)
        {
            if (driver.IsAvailable)
            {
                Console.WriteLine($"Available driver: {driver.Name}");
                return;
            }
        }
        Console.WriteLine("No available drivers.");
    }

    public void CompleteTrip(Trip trip)
    {
        trip.EndTrip();
        AvailableTrips.Remove(trip);
        Console.WriteLine("Trip completed.");
    }

    public void DisplayAllTrips()
    {
        Console.WriteLine("All Trips:");
        foreach (var trip in AvailableTrips)
        {
            trip.DisplayTripDetails();
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        RideSharingSystem system = new RideSharingSystem();

        while (true)
        {
            Console.WriteLine("1. Register as Rider");
            Console.WriteLine("2. Register as Driver");
            Console.WriteLine("3. Request Ride");
            Console.WriteLine("4. Accept Ride");
            Console.WriteLine("5. Complete Trip");
            Console.WriteLine("6. View Ride History");
            Console.WriteLine("7. Display All Trips");
            Console.WriteLine("8. Exit");

            Console.Write("Choose an option: ");
            int option = Convert.ToInt32(Console.ReadLine());

            switch (option)
            {
                case 1:
                    Rider rider = new Rider();
                    rider.Register();
                    system.RegisterUser(rider);
                    break;
                case 2:
                    Driver driver = new Driver();
                    driver.Register();
                    system.RegisterUser(driver);
                    break;
                case 3:
                    Console.Write("Enter your name: ");
                    string riderName = Console.ReadLine();
                    Rider riderRequest = system.RegisteredRiders.Find(r => r.Name == riderName);
                    if (riderRequest != null)
                    {
                        riderRequest.RequestRide(system);
                    }
                    else
                    {
                        Console.WriteLine("Rider not found.");
                    }
                    break;
                case 4:
                    Console.Write("Enter your name: ");
                    string driverName = Console.ReadLine();
                    Driver driverAccept = system.RegisteredDrivers.Find(d => d.Name == driverName);
                    if (driverAccept != null)
                    {
                        system.FindAvailableDriver();
                        if (system.AvailableTrips.Count > 0)
                        {
                            Trip trip = system.AvailableTrips[0];
                            driverAccept.AcceptRide(trip);
                        }
                    }
                    else
                    {
                        Console.WriteLine("Driver not found.");
                    }
                    break;
                case 5:
                    if (system.AvailableTrips.Count > 0)
                    {
                        Trip tripComplete = system.AvailableTrips[0];
                        system.CompleteTrip(tripComplete);
                    }
                    else
                    {
                        Console.WriteLine("No trips to complete.");
                    }
                    break;
                case 6:
                    Console.Write("Enter your name: ");
                    string userName = Console.ReadLine();
                    Rider riderView = system.RegisteredRiders.Find(r => r.Name == userName);
                    Driver driverView = system.RegisteredDrivers.Find(d => d.Name == userName);
                    if (riderView != null)
                    {
                        riderView.ViewRideHistory();
                    }
                    else if (driverView != null)
                    {
                        driverView.ViewTripHistory();
                    }
                    else
                    {
                        Console.WriteLine("User not found.");
                    }
                    break;
                case 7:
                    system.DisplayAllTrips();
                    break;
                case 8:
                    return;
                default:
                    Console.WriteLine("Invalid option.");
                    break;
            }
        }
    }
}